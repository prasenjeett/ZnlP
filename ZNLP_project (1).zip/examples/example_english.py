from znlp import ZNLP

nlp = ZNLP(language='english')
doc = nlp("The weather is very hot in New York today.")
for token in doc.tokens:
    print(f"{token.text} => POS: {token.pos}, Lemma: {token.lemma}, Entity: {token.entity}")
