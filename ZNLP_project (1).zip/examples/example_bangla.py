from znlp import ZNLP

nlp = ZNLP(language='bangla')
doc = nlp("ঢাকায় আজ খুব গরম।")
for token in doc.tokens:
    print(f"{token.text} => POS: {token.pos}, Lemma: {token.lemma}, Entity: {token.entity}")
