def normalize(text):
    return text.replace('‌', '').strip()
